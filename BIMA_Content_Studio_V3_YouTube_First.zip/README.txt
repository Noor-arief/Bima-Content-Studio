BIMA Content Studio V3

1. Open index.html in Chrome, Edge, Firefox, or Safari.
2. Calendar and prompt editing works offline; localStorage holds draft metadata.
3. Backup JSON regularly. Video attachments are local previews and NOT uploaded/stored on a server.
4. API and automatic publishing are NOT connected. Do not enter secrets into this HTML file.
5. The dashboard logo is embedded as a losslessly re-encoded pixel-identical copy of the user-supplied logo. The exact original file is also included.
6. Other channels remain in phase 2/later and do NOT reuse YouTube content.

GOOGLE OAUTH CHECKLIST (owner):
1. Sign into https://console.cloud.google.com/ using the Google identity that owns your desired YouTube channel.
2. Create Google Cloud project 'BIMA Content Studio'.
3. APIs & Services > Library > Enable YouTube Data API v3.
4. Google Auth Platform > Branding: BIMA Content Studio. Audience: External if using a consumer Gmail; add your own email as a test user during testing.
5. Data Access: request youtube.upload scope for uploads.
6. Clients > Create Client > Web application. Configure redirect URI ONLY after a secure HTTPS backend callback URL exists.
7. Keep Client Secret and OAuth refresh tokens exclusively on backend; never paste them in ChatGPT or HTML/JS.
8. Authorize account, upload a QA-approved test as PRIVATE, set valid future publishAt, verify schedule and actual channel ID.
9. Do not turn on automatic posting until confirmed with the correct channel, reliable storage, job idempotency, and error monitoring.

TikTok phase 2 will require separate eligible TikTok Shop Affiliate account, product showcase/commission, and TikTok Shop partner approval for affiliate APIs; ordinary TikTok video publishing access does not by itself guarantee a yellow basket.
